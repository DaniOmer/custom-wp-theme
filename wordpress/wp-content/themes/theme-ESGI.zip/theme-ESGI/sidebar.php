<aside>
	<?php dynamic_sidebar('sidebar_widget_zone') ?>
</aside>